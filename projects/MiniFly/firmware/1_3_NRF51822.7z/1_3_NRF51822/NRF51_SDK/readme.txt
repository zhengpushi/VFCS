To compile with Bluetooth suppot extract nrf51_sdk_v6_1_0_b2ec2e6.zip here or
run tools/build/download_deps.sh

http://developer.nordicsemi.com/nRF51_SDK/nRF51_SDK_v6.x.x/nrf51_sdk_v6_1_0_b2ec2e6.zip
